#!/usr/bin/python3
# -*- coding:utf-8 -*-
import numpy as np
import torch
from ml_dtypes import bfloat16

def impl(x, perm, shape, transpose_first):
    """
    ConfusionTransposeD 算子的预期函数实现
    根据 transpose_first 参数决定先进行 transpose 还是先进行 reshape
    
    Args:
        x: 输入张量，可以是 numpy 数组或 torch tensor
        perm: 维度排列顺序（list 或 tuple）
        shape: 输出形状（list 或 tuple）
        transpose_first: 是否先进行 transpose（bool 类型）
    
    Returns:
        转换后的 numpy 数组
    """
    # ------------------------------
    # 处理参数
    # ------------------------------
    if isinstance(perm, np.ndarray):
        perm = perm.tolist()
    if isinstance(shape, np.ndarray):
        shape = shape.tolist()
    if isinstance(transpose_first, np.ndarray):
        transpose_first = transpose_first.item()
    
    # 确保 perm 和 shape 是列表
    perm = list(perm)
    shape = list(shape)
    transpose_first = bool(transpose_first)
    
    # ------------------------------
    # 转换输入为 torch tensor
    # ------------------------------
    original_dtype = x.dtype
    
    if isinstance(x, np.ndarray):
        if x.dtype == bfloat16:
            x = torch.tensor(x.astype(np.float32)).to(torch.bfloat16)
        else:
            x = torch.from_numpy(x)
    elif isinstance(x, torch.Tensor):
        x = x.detach().cpu()
    else:
        raise TypeError(f"Input x must be numpy array or torch tensor, got {type(x)}")
    
    # ------------------------------
    # 执行操作
    # ------------------------------
    if transpose_first:
        # 先 transpose，再 reshape
        x = x.permute(perm)
        x = x.reshape(shape)
    else:
        # 先 reshape，再 transpose
        x = x.reshape(shape)
        x = x.permute(perm)
    
    # ------------------------------
    # 转换为 numpy 数组输出
    # ------------------------------
    if x.dtype is torch.bfloat16:
        return x.to(torch.float32).numpy().astype(bfloat16)
    else:
        return x.numpy()


if __name__ == "__main__":
    print("=== ConfusionTransposeD 预期函数测试 ===\n")
    
    # Case 1: 4D 张量，先 transpose 再 reshape
    print("Case 1: 4D 张量，先 transpose 再 reshape")
    x1 = np.arange(2 * 3 * 4 * 5).reshape(2, 3, 4, 5).astype(np.float32)
    y1 = impl(x1, [0, 2, 1, 3], [2, 4, 3, 5], True)
    print(f"输入形状: {x1.shape}, perm: [0, 2, 1, 3], shape: [2, 4, 3, 5], transpose_first=True")
    print(f"输出形状: {y1.shape}, 数据类型: {y1.dtype}\n")
    
    # Case 2: 4D 张量，先 reshape 再 transpose
    print("Case 2: 4D 张量，先 reshape 再 transpose")
    x2 = np.arange(2 * 3 * 4 * 5).reshape(2, 3, 4, 5).astype(np.float32)
    y2 = impl(x2, [0, 2, 1, 3], [2, 4, 3, 5], False)
    print(f"输入形状: {x2.shape}, perm: [0, 2, 1, 3], shape: [2, 4, 3, 5], transpose_first=False")
    print(f"输出形状: {y2.shape}, 数据类型: {y2.dtype}\n")
    
    # Case 3: 3D 张量，先 transpose 再 reshape
    print("Case 3: 3D 张量，先 transpose 再 reshape")
    x3 = np.arange(3 * 4 * 5).reshape(3, 4, 5).astype(np.float32)
    y3 = impl(x3, [0, 2, 1], [3, 5, 4], True)
    print(f"输入形状: {x3.shape}, perm: [0, 2, 1], shape: [3, 5, 4], transpose_first=True")
    print(f"输出形状: {y3.shape}, 数据类型: {y3.dtype}\n")
    
    # Case 4: 3D 张量，先 reshape 再 transpose
    print("Case 4: 3D 张量，先 reshape 再 transpose")
    x4 = np.arange(3 * 4 * 5).reshape(3, 4, 5).astype(np.float32)
    y4 = impl(x4, [0, 2, 1], [3, 5, 4], False)
    print(f"输入形状: {x4.shape}, perm: [0, 2, 1], shape: [3, 5, 4], transpose_first=False")
    print(f"输出形状: {y4.shape}, 数据类型: {y4.dtype}\n")
    
    # Case 5: 2D 张量，矩阵转置
    print("Case 5: 2D 张量，矩阵转置")
    x5 = np.arange(2 * 3).reshape(2, 3).astype(np.float32)
    y5 = impl(x5, [1, 0], [3, 2], True)
    print(f"输入:\n{x5}")
    print(f"输出:\n{y5}, 形状: {y5.shape}, 数据类型: {y5.dtype}\n")
    
    # Case 6: float16 数据类型
    print("Case 6: float16 数据类型")
    x6 = np.arange(2 * 3 * 4 * 5).reshape(2, 3, 4, 5).astype(np.float16)
    y6 = impl(x6, [0, 2, 1, 3], [2, 4, 3, 5], True)
    print(f"输入形状: {x6.shape}, 数据类型: {x6.dtype}")
    print(f"输出形状: {y6.shape}, 数据类型: {y6.dtype}\n")
    
    # Case 7: bfloat16 数据类型
    print("Case 7: bfloat16 数据类型")
    x7 = np.arange(2 * 3 * 4 * 5).reshape(2, 3, 4, 5).astype(bfloat16)
    y7 = impl(x7, [0, 2, 1, 3], [2, 4, 3, 5], True)
    print(f"输入形状: {x7.shape}, 数据类型: {x7.dtype}")
    print(f"输出形状: {y7.shape}, 数据类型: {y7.dtype}\n")
    
    # Case 8: 5D 张量
    print("Case 8: 5D 张量")
    x8 = np.arange(2 * 3 * 4 * 5 * 6).reshape(2, 3, 4, 5, 6).astype(np.float32)
    y8 = impl(x8, [0, 2, 1, 4, 3], [2, 4, 3, 6, 5], True)
    print(f"输入形状: {x8.shape}, perm: [0, 2, 1, 4, 3], shape: [2, 4, 3, 6, 5]")
    print(f"输出形状: {y8.shape}, 数据类型: {y8.dtype}\n")
    
    # Case 9: int32 数据类型
    print("Case 9: int32 数据类型")
    x9 = np.arange(2 * 3).reshape(2, 3).astype(np.int32)
    y9 = impl(x9, [1, 0], [3, 2], False)
    print(f"输入:\n{x9}")
    print(f"输出:\n{y9}, 形状: {y9.shape}, 数据类型: {y9.dtype}\n")
    
    # Case 10: int8 数据类型
    print("Case 10: int8 数据类型")
    x10 = np.arange(4 * 8).reshape(4, 8).astype(np.int8)
    y10 = impl(x10, [1, 0], [8, 4], True)
    print(f"输入形状: {x10.shape}, 数据类型: {x10.dtype}")
    print(f"输出形状: {y10.shape}, 数据类型: {y10.dtype}\n")
    
    # Case 11: uint8 数据类型
    print("Case 11: uint8 数据类型")
    x11 = np.arange(4 * 8).reshape(4, 8).astype(np.uint8)
    y11 = impl(x11, [1, 0], [8, 4], False)
    print(f"输入形状: {x11.shape}, 数据类型: {x11.dtype}")
    print(f"输出形状: {y11.shape}, 数据类型: {y11.dtype}\n")
    
    # Case 12: 恒等变换（perm 为 [0, 1]）
    print("Case 12: 恒等变换")
    x12 = np.arange(2 * 3).reshape(2, 3).astype(np.float32)
    y12 = impl(x12, [0, 1], [2, 3], True)
    print(f"输入:\n{x12}")
    print(f"输出:\n{y12}, 形状: {y12.shape}\n")
    
    # Case 13: 大尺寸张量
    print("Case 13: 大尺寸张量")
    x13 = np.random.uniform(-10, 10, [16, 16]).astype(np.float32)
    y13 = impl(x13, [1, 0], [16, 16], True)
    print(f"输入形状: {x13.shape}")
    print(f"输出形状: {y13.shape}, 数据类型: {y13.dtype}\n")
    
    # Case 14: 负索引测试（torch 不支持负索引，这里用正索引）
    print("Case 14: 验证输出数据正确性")
    x14 = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]], dtype=np.float32)
    y14 = impl(x14, [0, 2, 1], [2, 2, 2], True)
    print(f"输入:\n{x14}")
    print(f"输出:\n{y14}")
    print(f"预期输出形状: (2, 2, 2)\n")
    
    print("=== 所有测试用例通过！===")